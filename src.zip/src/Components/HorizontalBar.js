
import React, { useState } from 'react';
import '../css/HorizontalBar.css'
import '@fortawesome/fontawesome-free/css/all.min.css';


const HorizontalBar = ({ numbers }) => {
  const [startIndex, setStartIndex] = useState(0);
  const visibleNumbers = 4;
  const maxIndex = Math.max(numbers.length - visibleNumbers, 0);

  const scrollLeft = () => {
    setStartIndex((prevStartIndex) => Math.max(prevStartIndex - 4, 0));
  };

  const scrollRight = () => {
    setStartIndex((prevStartIndex) => Math.min(prevStartIndex + 4, maxIndex));
  };

  return (
    <body>
      <div className="horizontal-bar-container">
        <div className="horizontal-bar">
          <div className={`arrow left ${startIndex === 0 ? 'disabled' : ''}`} onClick={scrollLeft}>
            <i className="fas fa-arrow-left"></i>
          </div>
          <div className="numbers-container">
            {numbers.slice(startIndex, startIndex + visibleNumbers).map((number, index) => (
              <div key={index} className="number">
                {number}
              </div>
            ))}
          </div>
          <div className={`arrow right ${startIndex >= maxIndex ? 'disabled' : ''}`} onClick={scrollRight}>
            <i className="fas fa-arrow-right"></i>
          </div>
        </div>
      </div>
    </body>
  );
};

export default HorizontalBar;
