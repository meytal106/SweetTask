import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { connect } from 'react-redux';
import { fetchEpisodes, updateEpisodes } from '../Redux/redux';
import { Link } from 'react-router-dom';
import '../css/episode.css';

function EpisodesListComp({ episodes, updateEpisodes, characters, fetchCharacterDetails }) {
    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('https://rickandmortyapi.com/api/episode');
                updateEpisodes(response.data.results);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();

    }, [updateEpisodes]);

    const episodesS01 = new Set();
    const episodesS02 = new Set();

    if (episodes.length > 0) {
        episodes.forEach((episode) => {
            if (episode.episode.startsWith("S01")) {
                episodesS01.add(episode);
            } else if (episode.episode.startsWith("S02")) {
                episodesS02.add(episode);
            }
        });
    }

    return (
        <body>
            <div className="component-container">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQjTwAPw7gzDYbLvZrDsMYmmWA5zWab8iqKNQ&usqp=CAU" width="600" />

                <div className="season-container">
                    <div className="season-list season-list-left">
                        <div className='season'> <h2>Season 1</h2></div>
                        <section className="stage">
                            {Array.from(episodesS02).map((episode, index) => (
                                <div className="div" key={index}>
                                    <Link to={`/episode/${episode.id}`}>
                                        <p className='p' >{episode.name} -<br></br>{episode.air_date}</p>
                                    </Link>
                                </div>
                            ))}
                        </section>
                    </div>

                    <div className="season-list season-list-right">
                        <div className='season'> <h2>Season 2</h2></div>
                        <section className="stage">
                            {Array.from(episodesS01).map((episode, index) => (
                                <div className="div" key={index}>
                                    <Link to={`/episode/${episode.id}`}>
                                        <p className='p' >{episode.name} -<br></br>{episode.air_date}</p>
                                    </Link>
                                </div>
                            ))}
                        </section>
                    </div>
                </div>
            </div>
        </body>
    );
}

const mapStateToProps = (state) => ({
    episodes: state.episodes.episodes,
});

export default connect(mapStateToProps, { updateEpisodes })(EpisodesListComp);
