import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { updateEpisodes } from '../Redux/redux';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Link } from 'react-router-dom';

function EpisodeComp({ episodes, updateEpisodes }) {
    const { id } = useParams();
    const episode = episodes.find((e) => e.id === parseInt(id, 10));
    const [characterDetails, setCharacterDetails] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                if (!episode) {
                    const response = await axios.get('https://rickandmortyapi.com/api/episode');
                    updateEpisodes(response.data.results);
                    return;
                }

                const promises = episode.characters.map((characterUrl) => axios.get(characterUrl));
                const responses = await Promise.all(promises);
                const details = responses.map((response) => response.data);
                setCharacterDetails(details);
                setLoading(false);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, [episode, updateEpisodes]);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!episode) {
        return <div>Episode not found</div>;
    }

    return (
        <div>
            <div className='season'> <h2>{episode.name}</h2>
                <p>Air date: {episode.air_date}</p></div>

            <div className='epititle'>  <h2>Characters:</h2></div><br></br>
            <section className="stage2">
                {characterDetails.map((character, index) => (
                    <div className="div" key={index}>
                        <Link to={`/character/${character.id}`}>
                            <p className='p2'>{character.name}</p>
                        </Link>
                    </div>
                ))}
            </section>
        </div>
    );
}

const mapStateToProps = (state) => ({
    episodes: state.episodes.episodes,
});

export default connect(mapStateToProps, { updateEpisodes })(EpisodeComp);
