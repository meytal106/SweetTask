import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import '../css/episode.css';
import HorizontalBar from './HorizontalBar';

function CharacterPage({ characters }) {
  const { id } = useParams();
  const [characterDetails, setCharacterDetails] = useState(null);
  const [episodeNumbers, setEpisodeNumbers] = useState([]);

  useEffect(() => {
    const fetchCharacterDetails = async () => {
      try {
        const response = await axios.get(`https://rickandmortyapi.com/api/character/${id}`);
        setCharacterDetails(response.data);
        const numbers = response.data.episode.map((url) => {
          const matches = url.match(/\/episode\/(\d+)$/);
          return matches ? matches[1] : null;
        });
        setEpisodeNumbers(numbers);
      } catch (error) {
        console.error('Error fetching character details:', error);
      }
    };

    fetchCharacterDetails();
  }, [id]);

  if (!characterDetails) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <div className='season'> <h2>{characterDetails.name}</h2></div>
      <div className='character'>
        <p>Status: {characterDetails.status}</p>
        <p>Species: {characterDetails.species}</p>
        <p>Last known location: {characterDetails.location.name}</p>
        <p>First location: {characterDetails.origin.name}</p>
      </div>
      <div className='epititle'><h3>Episodes:</h3></div>

      <HorizontalBar numbers={episodeNumbers} />

      <img className='image' src={characterDetails.image} />
    </div>
  );
}

const mapStateToProps = (state) => ({
  characters: state.episodes.characterDetails,
});

export default connect(mapStateToProps)(CharacterPage);
