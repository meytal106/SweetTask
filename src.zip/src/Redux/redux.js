import axios from 'axios';

import { createStore, combineReducers } from 'redux';
const initialState = {
  episodes: [],
  characters: [],
  characterDetails: [],
};

const episodesReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'UPDATE_EPISODES':
      return { ...state, episodes: action.payload };
    case 'UPDATE_CHARACTERS':
      return { ...state, characters: action.payload };
    case 'UPDATE_CHARACTER_DETAILS':
      return { ...state, characterDetails: action.payload };
    default:
      return state;
  }
};
export const updateEpisodes = (episodes) => ({
  type: 'UPDATE_EPISODES',
  payload: episodes,
});

export const fetchEpisodes = () => async (dispatch) => {
  try {
    const response = await axios.get('https://rickandmortyapi.com/api/episode');
    dispatch(updateEpisodes(response.data.results));
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
export const updateCharacterDetails = (characterDetails) => ({
  type: 'UPDATE_CHARACTER_DETAILS',
  payload: characterDetails,
});
export const updateCharacters = (characters) => ({
  type: 'UPDATE_CHARACTERS',
  payload: characters,
});

export const fetchCharacters = () => (dispatch) => {
  axios.get('https://rickandmortyapi.com/api/characters')
    .then((response) => {
      dispatch({ type: 'FETCH_CHARACTERS_SUCCESS', payload: response.data });
    })
    .catch((error) => {
      dispatch({ type: 'FETCH_CHARACTERS_FAILURE', payload: error });
    });
};
export const fetchCharacterDetails = (characterUrls) => async (dispatch) => {
  try {
    const promises = characterUrls.map((url) => axios.get(url));
    const responses = await Promise.all(promises);
    const characterDetails = responses.map((response) => response.data);
    dispatch(updateCharacterDetails(characterDetails));
  } catch (error) {
    console.error('Error fetching character details:', error);
  }
};
const rootReducer = combineReducers({
  episodes: episodesReducer,
});

const store = createStore(rootReducer);




export default store;
