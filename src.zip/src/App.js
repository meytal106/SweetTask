import './App.css';
import { BrowserRouter } from 'react-router-dom';
import { Link, Route, Routes } from 'react-router-dom'
import EpisodesListComp from './Components/HomePage';
import EpisodeComp from './Components/EpisodePage'
import store from './Redux/redux';
import CharacterComp from './Components/CharacterPage'; 

import { createStore, combineReducers } from 'redux';
import { Provider } from 'react-redux';
function App() {
 return (
    <Provider store={store}>
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/" element={<EpisodesListComp />} />
          <Route path="/episode/:id" element={<EpisodeComp />} />
          <Route path="/character/:id" element={<CharacterComp />} />

          {/* Other routes go here */}
        </Routes>
      </div>
    </BrowserRouter>
    </Provider>
  );
}

export default App;
